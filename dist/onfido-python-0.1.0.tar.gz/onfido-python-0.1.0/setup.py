# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['onfido', 'onfido.resources']

package_data = \
{'': ['*']}

install_requires = \
['requests>=2.24.0,<3.0.0']

setup_kwargs = {
    'name': 'onfido-python',
    'version': '0.1.0',
    'description': 'The official wrapper for the Onfido API',
    'long_description': None,
    'author': 'Ben Ahmady',
    'author_email': 'ben.ahmady@onfido.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.6,<4',
}


setup(**setup_kwargs)
